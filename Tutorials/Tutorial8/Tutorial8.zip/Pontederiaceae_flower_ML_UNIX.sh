#!/bin/bash
for i in flower_models/Pontederiaceae_flower.model.ML.*; do
	foldername=${i/flower_models\//}
	foldername=${foldername/Pontederiaceae/Plants}
	foldername=${foldername/.model./_}
	foldername=${foldername/.nex/}
	foldername=${foldername/./_}
	mkdir $foldername
	sMap -t Pontederiaceae.tre -d Pontederiaceae_flower.txt -o $foldername/tutorial8 -n 1000 -i $i
done
