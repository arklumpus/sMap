#!/bin/bash
for i in flower_models/Pontederiaceae_flower.model.ML.*; do
	foldername=${i/flower_models\//}
	foldername=${foldername/Pontederiaceae/Plants}
	foldername=${foldername/.model./_}
	foldername=${foldername/.nex/}
	foldername=${foldername/./_}
	foldername=${foldername/ML/Bayes}
	mkdir $foldername
	sMap -t Pontederiaceae.treedist -T Pontederiaceae.tre -d Pontederiaceae_flower.txt -o $foldername/tutorial8 -n 1000 -i ${i/ML/Bayes} -ss --max-cov=1
done
