#!/bin/bash
for i in cond_models/*; do
	foldername=${i/cond_models\//}
	foldername=${foldername/Pontederiaceae/Plants}
	foldername=${foldername/.model./_}
	foldername=${foldername/.nex/}
	foldername=${foldername/./_}
	mkdir $foldername
	sMap -t Pontederiaceae.treedist -T Pontederiaceae.tre -d Pontederiaceae.txt -o $foldername/tutorial9 -n 1000 -i $i -ss --max-cov=1 --min-ess=1 --min-samples=5000 --ss-estimate-steps
done
